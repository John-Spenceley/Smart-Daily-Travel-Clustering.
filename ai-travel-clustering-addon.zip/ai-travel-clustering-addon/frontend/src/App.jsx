
import { useState } from "react";
import SearchForm from "./components/SearchForm.jsx";
import Itinerary from "./components/Itinerary.jsx";

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000";

export default function App() {
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleSearch({ destination, startDate, endDate, options }) {
    setLoading(true);
    try {
      // Demo POIs; replace with your actual generation flow
      const pois = [
        { title: "Louvre Museum", lat: 48.8606, lng: 2.3376, duration_min: 120, category: "museum" },
        { title: "Tuileries Garden", lat: 48.8635, lng: 2.3270, duration_min: 60,  category: "park" },
        { title: "Musée d'Orsay", lat: 48.8600, lng: 2.3266, duration_min: 90,  category: "museum" },
        { title: "Montmartre", lat: 48.8867, lng: 2.3431, duration_min: 90,  category: "district" },
        { title: "Sacré-Cœur", lat: 48.8867, lng: 2.3431, duration_min: 60,  category: "church" }
      ];

      let clustered = null;
      if (options?.enableClustering) {
        const res = await fetch(`${API_BASE}/optimize/cluster`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            pois,
            hotel: null,
            radius_km: options.radiusKm ?? 1.2,
            start_time: "09:00",
            end_time: "19:00",
            transport_mode: options.transportMode ?? "walk"
          })
        });
        const data = await res.json();
        clustered = data.days;
      }

      setPlan({ destination, startDate, endDate, days: clustered || [], radius_km: options?.radiusKm ?? 1.2 });
    } catch (e) {
      console.error(e);
      alert(`Failed to plan trip: ${e.message || e}`);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 960, margin: "0 auto", padding: 24 }}>
      <h1 style={{ textAlign: "center" }}>AI Travel Planner</h1>
      <SearchForm onSearch={handleSearch} />
      {loading && <div style={{ marginTop: 16, textAlign: "center" }}>Planning your clustered days…</div>}
      {plan && <Itinerary plan={plan} />}
    </div>
  );
}
