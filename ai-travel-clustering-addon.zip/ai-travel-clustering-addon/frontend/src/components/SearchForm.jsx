
import { useState } from "react";

export default function SearchForm({ onSearch }) {
  const [destination, setDestination] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [enableClustering, setEnableClustering] = useState(true);
  const [radiusKm, setRadiusKm] = useState(1.2);
  const [transportMode, setTransportMode] = useState("walk");

  const submit = (e) => {
    e.preventDefault();
    onSearch({
      destination,
      startDate,
      endDate,
      options: { enableClustering, radiusKm: Number(radiusKm), transportMode }
    });
  };

  const field = { padding: "8px", borderRadius: 8, border: "1px solid #ddd" };

  return (
    <form onSubmit={submit} style={{ display: "grid", gap: 12 }}>
      <input style={field} placeholder="Where to?" value={destination}
        onChange={(e) => setDestination(e.target.value)} required />

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <input type="date" style={field} value={startDate}
          onChange={(e) => setStartDate(e.target.value)} required />
        <input type="date" style={field} value={endDate}
          onChange={(e) => setEndDate(e.target.value)} required />
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", border: "1px solid #eee", padding: 12, borderRadius: 12 }}>
        <label style={{ fontWeight: 600 }}>Smart Travel Clustering</label>
        <input type="checkbox" checked={enableClustering}
          onChange={(e) => setEnableClustering(e.target.checked)} />
      </div>

      {enableClustering && (
        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: 12, alignItems: "center" }}>
          <label>Cluster radius (km)</label>
          <input type="range" min={0.5} max={5} step={0.1} value={radiusKm}
            onChange={(e) => setRadiusKm(e.target.value)} />

          <div style={{ gridColumn: "1 / span 2", fontSize: 12, color: "#666" }}>
            Current: {radiusKm} km
          </div>

          <label>Mode</label>
          <select style={field} value={transportMode} onChange={(e) => setTransportMode(e.target.value)}>
            <option value="walk">Walk</option>
            <option value="transit">Transit</option>
            <option value="drive">Drive</option>
          </select>
        </div>
      )}

      <button style={{ padding: "10px 16px", borderRadius: 12, fontWeight: 700, background: "black", color: "white" }}>
        Plan Trip
      </button>
    </form>
  );
}
