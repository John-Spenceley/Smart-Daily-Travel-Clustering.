
function Badge({ children }) {
  return <span style={{ display: "inline-block", fontSize: 12, padding: "2px 8px", borderRadius: 999, border: "1px solid #ddd" }}>{children}</span>;
}

export default function Itinerary({ plan }) {
  if (!plan?.days?.length) return <div style={{ marginTop: 24 }}>No clustered plan yet. Try enabling clustering.</div>;

  return (
    <div style={{ marginTop: 24, display: "grid", gap: 24 }}>
      {plan.days.map((day) => (
        <div key={day.day} style={{ borderRadius: 16, boxShadow: "0 1px 8px rgba(0,0,0,0.08)", padding: 16 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
            <h2 style={{ margin: 0 }}>Day {day.day}</h2>
            <div style={{ display: "flex", gap: 8 }}>
              <Badge>Within ~{day.summary.within_km} km</Badge>
              <Badge>{day.summary.stops} stops</Badge>
            </div>
          </div>

          <ol style={{ display: "grid", gap: 12, paddingLeft: 20 }}>
            {day.items.map((it, idx) => (
              <li key={idx} style={{ border: "1px solid #eee", borderRadius: 12, padding: 12 }}>
                <div style={{ fontWeight: 600 }}>{it.title}</div>
                <div style={{ fontSize: 14, color: "#555" }}>{it.start} → {it.end} • {it.duration_min} min on site</div>
                {idx > 0 && (
                  <div style={{ fontSize: 12, color: "#777", marginTop: 4 }}>
                    Travel: ~{it.travel_min} min • ~{it.distance_km} km
                  </div>
                )}
              </li>
            ))}
          </ol>
        </div>
      ))}
    </div>
  );
}
