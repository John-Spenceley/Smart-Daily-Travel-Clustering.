
# AI Travel — Smart Daily Travel Clustering (Backend + Frontend)

This repo packages a **drop-in feature** you can demo or merge into an existing travel-planner:
- **Backend (FastAPI)**: `/optimize/cluster` endpoint that groups POIs by proximity and packs them into daily schedules.
- **Frontend (Vite + React)**: a simple UI with **Smart Travel Clustering** toggle, radius control, transport mode, and **clustered day** display.

You can use this as:
1) A **standalone demo** (works out of the box), or
2) A **feature branch** you copy into your existing repo (e.g., `travel-ai-agent-crew`).

---

## Quick Start

### 1) Backend

```bash
cd backend
python -m venv .venv
# Windows
.venv\Scripts\activate
# Mac/Linux
source .venv/bin/activate

pip install -r requirements.txt
python main.py
```
Open http://localhost:8000/docs and try **POST /optimize/cluster** with the sample payload in the docs.

### 2) Frontend

```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173 and run a demo plan.

---

## How It Works

- We compute Haversine distances between POIs and do **radius-based clustering** (default 1.2km).
- Inside each cluster we use a **greedy nearest-neighbor** ordering (TSP-ish).
- We **pack** items into **days** within a daily time window (default 09:00–19:00), estimating travel time by mode.
- The UI shows **Within ~X km** and **stops** badges per day; each leg includes **travel minutes** and **distance**.

---

## Merge Into Existing Project (e.g., `travel-ai-agent-crew`)

**Backend**
- Copy `backend/helpers/clustering.py` -> your `helpers/` (or `app/utils/`).
- Copy `backend/services/optimize.py` -> your `services/` (or `app/routers/`).
- In your `main.py`, include:
  ```python
  from services import optimize
  app.include_router(optimize.router)
  ```
- Ensure CORS allows your frontend origin.

**Frontend**
- Copy:
  - `frontend/src/components/SearchForm.jsx`
  - `frontend/src/components/Itinerary.jsx`
  - `frontend/src/App.jsx` (merge the handler bits if you already have an App)
- Make sure `VITE_API_BASE` (or default) points to your backend (http://localhost:8000).

---

## Roadmap

- Swap rough leg times with **Google Directions API**.
- Add **Day Map** (Leaflet) drawing the daily path.
- **Budget Engine** and **Personality Modes** prior to clustering.

---

## License

MIT
